# ProjectLog PWA – Verifikationsprotokoll

## Automatisierte Prüfungen

- Node-Test-Suite für Domäne, Router, Repository, UI-Vertrag und PWA-Konfiguration
- JavaScript-Syntaxprüfung aller produktiven Module
- Integrationsworkflow: Projekt → Bug → Idee → Änderung → Aktivität → Export → Import → kaskadierendes Löschen
- HTTP-Auslieferung aller im Service Worker gelisteten App-Shell-Dateien
- Prüfung der Manifest-Parameter für Standalone-PWA
- Prüfung der PNG-Abmessungen 192 × 192, 512 × 512 und 180 × 180

## Sicherheits- und Konsistenzprüfungen

- URL-Kommandos erlauben nur Navigation und vorausgefüllte Erfassung.
- Unbekannte oder destruktive URL-Aktionen werden verworfen.
- Backup-Import validiert vollständig vor dem Ersetzen der Daten.
- Projektlöschung entfernt zugehörige Bugs und Ideen in derselben Datenbanktransaktion.
- Aktivität wird aus den Entitäten abgeleitet und nicht redundant gespeichert.
- Benutzereingaben werden vor dem Einsetzen in HTML maskiert.

## Visuelle Prüfpunkte

1. Mobile-first-Aufbau mit festem Header und unterer Tab-Bar
2. Touch-Ziele mit mindestens 44 px Höhe
3. Safe-Area-Abstände für Statusleiste und Home-Indikator
4. Light- und Dark-Mode-Tokens
5. Listenbasierter statt kartenlastiger Containeraufbau
6. modales Bottom-Sheet für Erfassung und Bearbeitung
7. semantische Status- und Prioritätskennzeichnung
8. reduzierte Animation bei `prefers-reduced-motion`

## Nicht automatisierbarer Resttest

Die verfügbare Chromium-Installation erzwingt per administrativer Richtlinie eine globale URL-Blockliste. Dadurch war keine Browsernavigation zu localhost, Datei-URLs oder Data-URLs möglich. Diese Richtlinie wurde nicht umgangen.

Daher bleibt als reale Zielgeräteprüfung offen:

- Öffnen der HTTPS-Adresse in Mobile Safari
- Installation über „Zum Home-Bildschirm“
- Start im Standalone-Modus
- Anlegen und Bearbeiten von Projekt, Bug und Idee
- Neustart und Persistenzkontrolle
- Flugmodus und Offline-Neustart nach einmaligem Online-Laden
- JSON-Export über Teilen oder Download
- Aufruf eines URL-Kommandos über Apple Kurzbefehle

## Bekannte Plattformgrenze

Eine PWA kann unter iOS kein eigenes natives URL-Scheme wie `projectlog://` registrieren. ProjectLog verwendet deshalb sichere HTTPS-Parameter.
