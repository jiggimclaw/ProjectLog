# ProjectLog PWA Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Eine offlinefähige, installierbare iPhone-PWA für Projekte, Bugs und Änderungsideen mit stabilen IDs, Zeitstempeln, lokaler Speicherung, Backup und URL-Aktionen erstellen.

**Architecture:** Dependency-freie statische ES-Module trennen Domänenlogik, IndexedDB, URL-Routing und UI. Ein Service Worker cached die App-Shell; ein versioniertes JSON-Format übernimmt Export und atomar validierten Import.

**Tech Stack:** HTML5, CSS, JavaScript ES2022 Modules, IndexedDB, Service Worker, Web App Manifest, Node.js `node:test`, Python Playwright mit System-Chromium.

## Global Constraints

- Keine Laufzeit-Abhängigkeiten und kein Backend.
- Mobile-first und auf iPhone-Safe-Areas ausgelegt.
- Persistenz ausschließlich lokal in IndexedDB.
- URL-Aktionen dürfen keine destruktiven Änderungen automatisch ausführen.
- Light Mode und Dark Mode müssen unterstützt werden.
- Der Kernworkflow muss nach dem ersten Laden offline funktionieren.

---

### Task 1: Domänenmodell und Backup-Validierung

**Files:**
- Create: `src/domain.js`
- Create: `tests/domain.test.js`
- Create: `package.json`

**Interfaces:**
- Produces: `createProject`, `createBug`, `createIdea`, `touchEntity`, `formatSequenceId`, `validateBackup`, `buildBackup`, `deriveActivity`.

- [ ] Tests für IDs, Zeitstempel, Normalisierung, Backup-Referenzen und Aktivität schreiben.
- [ ] Tests ausführen und erwartetes Fehlschlagen wegen fehlendem Modul bestätigen.
- [ ] Minimale Domänenimplementierung erstellen.
- [ ] Gesamte Testsuite grün ausführen.
- [ ] Änderungen committen.

### Task 2: URL-Kommandos

**Files:**
- Create: `src/router.js`
- Create: `tests/router.test.js`

**Interfaces:**
- Produces: `parseLaunchCommand(url)` mit sicheren Navigation- und Formularbefehlen.

- [ ] Tests für erlaubte, ungültige und destruktive Parameter schreiben.
- [ ] Tests ausführen und erwartetes Fehlschlagen bestätigen.
- [ ] Parser minimal implementieren.
- [ ] Gesamte Testsuite grün ausführen.
- [ ] Änderungen committen.

### Task 3: IndexedDB-Repository

**Files:**
- Create: `src/storage.js`
- Create: `tests/storage-contract.test.js`

**Interfaces:**
- Produces: `ProjectLogRepository` mit `init`, `list`, `get`, `put`, `remove`, `nextSequence`, `exportBackup`, `importBackup`, `clearAll`.

- [ ] Vertragstests für öffentliche Methoden und atomare Importreihenfolge schreiben.
- [ ] Tests ausführen und erwartetes Fehlschlagen bestätigen.
- [ ] Repository implementieren.
- [ ] Gesamte Testsuite grün ausführen.
- [ ] Änderungen committen.

### Task 4: App-Shell und HIG-orientierte Oberfläche

**Files:**
- Create: `index.html`
- Create: `styles.css`
- Create: `src/app.js`
- Create: `src/icons.js`

**Interfaces:**
- Consumes: Domänen-, Router- und Repository-Schnittstellen.
- Produces: funktionsfähige Projekte-, Aktivitäts-, Einstellungs-, Detail- und Editoransichten.

- [ ] Browser-Abnahmetest für Grundstruktur und Barrierefreiheitsmerkmale schreiben.
- [ ] Test ausführen und erwartetes Fehlschlagen bestätigen.
- [ ] App-Shell, Navigation und renderbasierte UI implementieren.
- [ ] Formulare, Filter, Suche, Bestätigungen und Toasts anbinden.
- [ ] Browser-Abnahmetest grün ausführen.
- [ ] Änderungen committen.

### Task 5: PWA, Offline und Icons

**Files:**
- Create: `manifest.webmanifest`
- Create: `service-worker.js`
- Create: `icons/icon-192.png`
- Create: `icons/icon-512.png`
- Create: `icons/apple-touch-icon.png`
- Create: `tests/pwa.test.js`

**Interfaces:**
- Produces: installierbare App-Shell und Offline-Cache `projectlog-shell-v1`.

- [ ] Manifest- und Service-Worker-Tests schreiben.
- [ ] Tests ausführen und erwartetes Fehlschlagen bestätigen.
- [ ] Manifest, Service Worker und Icons erstellen.
- [ ] Gesamte Testsuite grün ausführen.
- [ ] Änderungen committen.

### Task 6: End-to-End-Verifikation und Handoff

**Files:**
- Create: `tests/e2e.py`
- Create: `README.md`
- Create: `docs/verification.md`

**Interfaces:**
- Produces: reproduzierbare Browserprüfung, Installationsanleitung und dokumentierte Einschränkungen.

- [ ] E2E-Test für Projekt, Bug, Idee, Reload-Persistenz, URL-Aktion, Export und Offline-Laden schreiben.
- [ ] Test ausführen und Fehler beheben, bis er vollständig besteht.
- [ ] Mobile Screenshots in Light und Dark Mode erzeugen und prüfen.
- [ ] README und Verifikationsprotokoll erstellen.
- [ ] Gesamte Testsuite und E2E-Test erneut ausführen.
- [ ] Bereinigtes ZIP erzeugen und finalen Stand committen.
