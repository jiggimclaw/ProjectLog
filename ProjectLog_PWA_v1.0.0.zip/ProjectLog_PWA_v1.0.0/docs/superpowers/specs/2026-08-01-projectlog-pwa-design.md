# ProjectLog PWA – Design Specification

## Ziel

Eine vollständig lokale, installierbare iPhone-PWA zur Verwaltung von Projekten, zugehörigen Bugs und Änderungsideen. Alle Einträge erhalten stabile IDs sowie Erstellungs- und Änderungszeitstempel. Die App funktioniert offline und benötigt weder Benutzerkonto noch Backend.

## Informationsarchitektur

- **Projekte:** Projektliste mit Suchfeld, offenen Bug-Zahlen und letzter Aktivität.
- **Aktivität:** Chronologische Liste aller erstellten und geänderten Projekte, Bugs und Ideen.
- **Einstellungen:** JSON-Export, JSON-Import, Beispieldaten zurücksetzen und Installationshinweise.
- **Projektdetail:** Segmentierte Ansichten für Übersicht, Bugs und Ideen.
- **Editor:** Modales Formular für Projekte, Bugs und Ideen; destruktive Aktionen erfordern Bestätigung.

## Datenmodell

### Project

- `id`: `PRJ-` plus UUID-Kurzform
- `name`: 1–80 Zeichen
- `description`: 0–2000 Zeichen
- `createdAt`: ISO-8601
- `updatedAt`: ISO-8601

### Bug

- `id`: projektübergreifend fortlaufend, Format `BUG-0001`
- `projectId`: ID des Projekts
- `title`: 1–120 Zeichen
- `description`: 0–4000 Zeichen
- `status`: `open`, `in_progress`, `resolved`, `rejected`
- `priority`: `low`, `medium`, `high`, `critical`
- `createdAt`: ISO-8601
- `updatedAt`: ISO-8601

### Idea

- `id`: projektübergreifend fortlaufend, Format `IDEA-0001`
- `projectId`: ID des Projekts
- `title`: 1–120 Zeichen
- `description`: 0–4000 Zeichen
- `status`: `new`, `planned`, `implemented`, `rejected`
- `createdAt`: ISO-8601
- `updatedAt`: ISO-8601

### Activity

Aktivität wird nicht separat persistiert, sondern aus `createdAt` und `updatedAt` aller Entitäten abgeleitet. Dadurch entsteht keine zweite, inkonsistente Wahrheit.

## Speicherung

- IndexedDB-Datenbank `projectlog-db`, Version 1.
- Stores: `projects`, `bugs`, `ideas`, `meta`.
- `meta` enthält die Zähler für Bug- und Ideen-IDs.
- JSON-Export mit Schema-Version `projectlog.backup.v1`.
- Import validiert Schema, Entitäten und Referenzen vor dem Überschreiben.

## URL-Steuerung

Die App wertet beim Start URL-Parameter aus:

- `?action=new-project`
- `?action=new-bug&project=<projectId>&title=<optional>`
- `?action=new-idea&project=<projectId>&title=<optional>`
- `?project=<projectId>&view=overview|bugs|ideas`

Eingehende URLs dürfen nur navigieren oder ein vorausgefülltes Formular öffnen. Löschen, Importieren oder Statusänderungen werden nie ohne Benutzerinteraktion ausgeführt.

## Gestaltung

- Mobile-first, Apple-HIG-orientiert ohne vorzutäuschen, native UIKit-Komponenten zu sein.
- Systemschrift `-apple-system`, klare Navigation, große Touch-Ziele, reduzierte Ebenen.
- Untere Tab-Bar mit drei Zielen.
- Semantische Farben für Status und Priorität, kompatibel mit Light und Dark Mode.
- Keine dekorativen Kartenraster; primär Listen, gruppierte Flächen und modale Sheets.
- Safe-Area-Unterstützung für iPhone mit Home-Indikator und Dynamic Island.

## Offline- und Installationsverhalten

- Web-App-Manifest mit Standalone-Modus, Hochformat, Icons und Theme-Farben.
- Service Worker mit App-Shell-Cache und Network-first-Fallback für Navigationsanfragen.
- Alle Kernfunktionen sind nach dem ersten erfolgreichen Laden offline verfügbar.

## Fehlerbehandlung

- Validierungsfehler werden direkt am Formular angezeigt.
- Speicherfehler erzeugen eine nicht-blockierende Fehlermeldung mit konkreter Handlung.
- Importfehler verändern vorhandene Daten nicht.
- Nicht vorhandene Projekt-IDs aus URLs führen zur Projektübersicht und einer Warnung.

## Nicht-Ziele der V1

- Cloud-Synchronisation
- Mehrbenutzerbetrieb
- Dateianhänge
- Kommentare
- vollständige Änderungsverläufe je Feld
- natives eigenes URL-Scheme
