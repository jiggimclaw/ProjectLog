from __future__ import annotations

import contextlib
import http.server
import json
import re
import socketserver
import subprocess
import threading
import urllib.request
from pathlib import Path

from PIL import Image

ROOT = Path(__file__).resolve().parents[1]


class QuietHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *_args):
        pass


class ReusableTCPServer(socketserver.TCPServer):
    allow_reuse_address = True


@contextlib.contextmanager
def static_server():
    handler = lambda *args, **kwargs: QuietHandler(*args, directory=ROOT, **kwargs)
    with ReusableTCPServer(("127.0.0.1", 0), handler) as server:
        port = server.server_address[1]
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            yield port
        finally:
            server.shutdown()
            thread.join(timeout=2)


def fetch(port: int, path: str) -> tuple[int, bytes]:
    with urllib.request.urlopen(f"http://127.0.0.1:{port}/{path}", timeout=5) as response:
        return response.status, response.read()


def main():
    result = subprocess.run(
        ["node", "tests/workflow.mjs"],
        cwd=ROOT,
        check=True,
        capture_output=True,
        text=True,
    )
    workflow = json.loads(result.stdout)
    assert workflow["workflow"] == "passed"

    with static_server() as port:
        status, index = fetch(port, "")
        assert status == 200
        assert b"ProjectLog" in index

        status, manifest_raw = fetch(port, "manifest.webmanifest")
        assert status == 200
        manifest = json.loads(manifest_raw)
        assert manifest["display"] == "standalone"

        status, worker_raw = fetch(port, "service-worker.js")
        assert status == 200
        worker = worker_raw.decode("utf-8")
        shell_assets = re.findall(r"'\./([^']+)'", worker.split("self.addEventListener('install'", 1)[0])
        for asset in shell_assets:
            asset_status, body = fetch(port, asset)
            assert asset_status == 200, asset
            assert body, asset

    expected_sizes = {
        "icons/icon-192.png": (192, 192),
        "icons/icon-512.png": (512, 512),
        "icons/apple-touch-icon.png": (180, 180),
    }
    for relative, expected in expected_sizes.items():
        with Image.open(ROOT / relative) as image:
            assert image.size == expected
            assert image.mode in {"RGB", "RGBA"}

    print(json.dumps({
        "http_assets": "passed",
        "workflow": workflow,
        "icons": expected_sizes,
    }, ensure_ascii=False))


if __name__ == "__main__":
    main()
