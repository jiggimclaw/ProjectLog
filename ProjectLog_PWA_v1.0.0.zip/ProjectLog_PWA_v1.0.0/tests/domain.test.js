import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildBackup,
  createBug,
  createIdea,
  createProject,
  deriveActivity,
  formatSequenceId,
  touchEntity,
  validateBackup,
} from '../src/domain.js';

const NOW = '2026-08-01T12:00:00.000Z';
const LATER = '2026-08-01T13:15:00.000Z';

test('formatSequenceId pads positive integer sequences', () => {
  assert.equal(formatSequenceId('BUG', 1), 'BUG-0001');
  assert.equal(formatSequenceId('IDEA', 42), 'IDEA-0042');
  assert.throws(() => formatSequenceId('BUG', 0), /positive integer/i);
});

test('createProject trims input and stamps stable metadata', () => {
  const project = createProject(
    { name: '  PlasmaLog  ', description: '  Bestand sauber planen.  ' },
    { now: NOW, id: 'PRJ-ABC123' },
  );

  assert.deepEqual(project, {
    id: 'PRJ-ABC123',
    name: 'PlasmaLog',
    description: 'Bestand sauber planen.',
    createdAt: NOW,
    updatedAt: NOW,
  });
});

test('createBug assigns sequence ID, defaults and timestamps', () => {
  const bug = createBug(
    { projectId: 'PRJ-ABC123', title: '  Filter springt zurück  ' },
    { sequence: 7, now: NOW },
  );

  assert.deepEqual(bug, {
    id: 'BUG-0007',
    projectId: 'PRJ-ABC123',
    title: 'Filter springt zurück',
    description: '',
    status: 'open',
    priority: 'medium',
    createdAt: NOW,
    updatedAt: NOW,
  });
});

test('createIdea validates status and creates an idea', () => {
  const idea = createIdea(
    {
      projectId: 'PRJ-ABC123',
      title: 'CSV-Import',
      description: 'Optionaler Import.',
      status: 'planned',
    },
    { sequence: 3, now: NOW },
  );

  assert.equal(idea.id, 'IDEA-0003');
  assert.equal(idea.status, 'planned');
  assert.throws(
    () => createIdea({ projectId: 'P', title: 'X', status: 'unknown' }, { sequence: 4, now: NOW }),
    /invalid idea status/i,
  );
});

test('touchEntity preserves identity and creation time while updating timestamp', () => {
  const original = createBug(
    { projectId: 'PRJ-ABC123', title: 'Alt' },
    { sequence: 1, now: NOW },
  );
  const updated = touchEntity(original, { title: 'Neu', status: 'resolved' }, LATER);

  assert.equal(updated.id, original.id);
  assert.equal(updated.createdAt, NOW);
  assert.equal(updated.updatedAt, LATER);
  assert.equal(updated.title, 'Neu');
  assert.equal(updated.status, 'resolved');
});

test('buildBackup and validateBackup preserve valid related data', () => {
  const project = createProject({ name: 'ProjectLog' }, { now: NOW, id: 'PRJ-ONE' });
  const bug = createBug({ projectId: project.id, title: 'Testbug' }, { sequence: 1, now: NOW });
  const idea = createIdea({ projectId: project.id, title: 'Testidee' }, { sequence: 1, now: NOW });
  const backup = buildBackup({
    projects: [project],
    bugs: [bug],
    ideas: [idea],
    meta: { bugSequence: 1, ideaSequence: 1 },
  }, NOW);

  assert.equal(backup.schema, 'projectlog.backup.v1');
  assert.deepEqual(validateBackup(backup), backup);
});

test('validateBackup rejects orphaned entities without mutating input', () => {
  const backup = {
    schema: 'projectlog.backup.v1',
    exportedAt: NOW,
    data: {
      projects: [],
      bugs: [{
        id: 'BUG-0001', projectId: 'PRJ-MISSING', title: 'Orphan', description: '',
        status: 'open', priority: 'medium', createdAt: NOW, updatedAt: NOW,
      }],
      ideas: [],
      meta: { bugSequence: 1, ideaSequence: 0 },
    },
  };
  const snapshot = structuredClone(backup);

  assert.throws(() => validateBackup(backup), /unknown project/i);
  assert.deepEqual(backup, snapshot);
});

test('deriveActivity emits one latest event per entity sorted newest first', () => {
  const project = createProject({ name: 'ProjectLog' }, { now: NOW, id: 'PRJ-ONE' });
  const bug = touchEntity(
    createBug({ projectId: project.id, title: 'Bug' }, { sequence: 1, now: NOW }),
    { status: 'resolved' },
    LATER,
  );
  const idea = createIdea({ projectId: project.id, title: 'Idee' }, { sequence: 1, now: NOW });

  const activity = deriveActivity({ projects: [project], bugs: [bug], ideas: [idea] });

  assert.equal(activity.length, 3);
  assert.equal(activity[0].entityId, bug.id);
  assert.equal(activity[0].action, 'updated');
  assert.equal(activity[0].timestamp, LATER);
  assert.equal(activity[1].timestamp, NOW);
});
