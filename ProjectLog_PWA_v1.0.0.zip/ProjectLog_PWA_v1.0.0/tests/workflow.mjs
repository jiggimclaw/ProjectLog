import assert from 'node:assert/strict';
import {
  createBug,
  createIdea,
  createProject,
  deriveActivity,
  touchEntity,
} from '../src/domain.js';
import { parseLaunchCommand } from '../src/router.js';
import { MemoryProjectLogDriver, ProjectLogRepository } from '../src/storage.js';

const T0 = '2026-08-01T12:00:00.000Z';
const T1 = '2026-08-01T12:30:00.000Z';

const source = new ProjectLogRepository({ driver: new MemoryProjectLogDriver(), now: () => T1 });
await source.init();

const project = createProject({ name: 'ProjectLog', description: 'E2E' }, { id: 'PRJ-E2E0001', now: T0 });
await source.put('projects', project);
const bug = createBug({ projectId: project.id, title: 'Offline testen', priority: 'high' }, {
  sequence: await source.nextSequence('bug'), now: T0,
});
await source.put('bugs', bug);
const idea = createIdea({ projectId: project.id, title: 'URL öffnen', status: 'planned' }, {
  sequence: await source.nextSequence('idea'), now: T0,
});
await source.put('ideas', idea);

const updatedBug = touchEntity(bug, { status: 'resolved' }, T1);
await source.put('bugs', updatedBug);
const activity = deriveActivity({
  projects: await source.list('projects'),
  bugs: await source.list('bugs'),
  ideas: await source.list('ideas'),
});
assert.equal(activity[0].entityId, 'BUG-0001');
assert.equal(activity[0].action, 'updated');

const backup = await source.exportBackup();
const restored = new ProjectLogRepository({ driver: new MemoryProjectLogDriver(), now: () => T1 });
await restored.init();
await restored.importBackup(backup);
assert.equal((await restored.list('projects')).length, 1);
assert.equal((await restored.list('bugs'))[0].status, 'resolved');
assert.equal((await restored.list('ideas'))[0].status, 'planned');

const command = parseLaunchCommand(`https://example.test/?action=new-bug&project=${project.id}&title=Aus%20Kurzbefehl`);
assert.deepEqual(command, {
  type: 'new-bug', projectId: project.id, title: 'Aus Kurzbefehl',
});

await restored.removeProjectCascade(project.id);
assert.equal((await restored.list('projects')).length, 0);
assert.equal((await restored.list('bugs')).length, 0);
assert.equal((await restored.list('ideas')).length, 0);

console.log(JSON.stringify({
  workflow: 'passed',
  projectId: project.id,
  bugId: bug.id,
  ideaId: idea.id,
  backupSchema: backup.schema,
}));
