import test from 'node:test';
import assert from 'node:assert/strict';
import { createBug, createProject } from '../src/domain.js';
import { MemoryProjectLogDriver, ProjectLogRepository } from '../src/storage.js';

const NOW = '2026-08-01T12:00:00.000Z';

async function createRepository() {
  const driver = new MemoryProjectLogDriver();
  const repository = new ProjectLogRepository({ driver, now: () => NOW });
  await repository.init();
  return { driver, repository };
}

test('init creates zeroed sequence metadata once', async () => {
  const { repository } = await createRepository();

  assert.equal(await repository.nextSequence('bug'), 1);
  assert.equal(await repository.nextSequence('bug'), 2);
  assert.equal(await repository.nextSequence('idea'), 1);
});

test('put, get, list and remove preserve entities by store', async () => {
  const { repository } = await createRepository();
  const project = createProject({ name: 'ProjectLog' }, { id: 'PRJ-ONE', now: NOW });

  await repository.put('projects', project);

  assert.deepEqual(await repository.get('projects', project.id), project);
  assert.deepEqual(await repository.list('projects'), [project]);
  await repository.remove('projects', project.id);
  assert.equal(await repository.get('projects', project.id), undefined);
});

test('removeProjectCascade deletes project and related bugs and ideas only', async () => {
  const { repository } = await createRepository();
  const first = createProject({ name: 'First' }, { id: 'PRJ-ONE', now: NOW });
  const second = createProject({ name: 'Second' }, { id: 'PRJ-TWO', now: NOW });
  await repository.put('projects', first);
  await repository.put('projects', second);
  await repository.put('bugs', createBug({ projectId: first.id, title: 'First bug' }, { sequence: 1, now: NOW }));
  await repository.put('bugs', createBug({ projectId: second.id, title: 'Second bug' }, { sequence: 2, now: NOW }));
  await repository.put('ideas', {
    id: 'IDEA-0001', projectId: first.id, title: 'Idea', description: '', status: 'new',
    createdAt: NOW, updatedAt: NOW,
  });

  await repository.removeProjectCascade(first.id);

  assert.deepEqual((await repository.list('projects')).map((item) => item.id), ['PRJ-TWO']);
  assert.deepEqual((await repository.list('bugs')).map((item) => item.id), ['BUG-0002']);
  assert.deepEqual(await repository.list('ideas'), []);
});

test('exportBackup returns all stores and current counters', async () => {
  const { repository } = await createRepository();
  const project = createProject({ name: 'ProjectLog' }, { id: 'PRJ-ONE', now: NOW });
  await repository.put('projects', project);
  await repository.nextSequence('bug');

  const backup = await repository.exportBackup();

  assert.equal(backup.schema, 'projectlog.backup.v1');
  assert.deepEqual(backup.data.projects, [project]);
  assert.deepEqual(backup.data.meta, { bugSequence: 1, ideaSequence: 0 });
});

test('invalid import leaves existing data unchanged', async () => {
  const { repository } = await createRepository();
  const project = createProject({ name: 'Existing' }, { id: 'PRJ-ONE', now: NOW });
  await repository.put('projects', project);

  await assert.rejects(
    repository.importBackup({ schema: 'wrong', exportedAt: NOW, data: {} }),
    /unsupported backup schema/i,
  );

  assert.deepEqual(await repository.list('projects'), [project]);
});

test('valid import replaces all stores atomically', async () => {
  const { repository } = await createRepository();
  await repository.put('projects', createProject({ name: 'Old' }, { id: 'PRJ-OLD', now: NOW }));
  const replacement = createProject({ name: 'New' }, { id: 'PRJ-NEW', now: NOW });

  await repository.importBackup({
    schema: 'projectlog.backup.v1',
    exportedAt: NOW,
    data: {
      projects: [replacement],
      bugs: [],
      ideas: [],
      meta: { bugSequence: 4, ideaSequence: 2 },
    },
  });

  assert.deepEqual(await repository.list('projects'), [replacement]);
  assert.equal(await repository.nextSequence('bug'), 5);
  assert.equal(await repository.nextSequence('idea'), 3);
});
