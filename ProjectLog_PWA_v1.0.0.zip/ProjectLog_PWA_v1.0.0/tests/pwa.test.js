import test from 'node:test';
import assert from 'node:assert/strict';
import { access, readFile } from 'node:fs/promises';

async function text(path) {
  return readFile(new URL(`../${path}`, import.meta.url), 'utf8');
}

test('manifest defines an installable standalone iPhone app', async () => {
  const manifest = JSON.parse(await text('manifest.webmanifest'));
  assert.equal(manifest.name, 'ProjectLog');
  assert.equal(manifest.display, 'standalone');
  assert.equal(manifest.orientation, 'portrait-primary');
  assert.equal(manifest.start_url, './');
  assert.equal(manifest.scope, './');
  assert.equal(manifest.icons.some((item) => item.sizes === '192x192' && item.purpose.includes('maskable')), true);
  assert.equal(manifest.icons.some((item) => item.sizes === '512x512'), true);
});

test('service worker caches the complete app shell and handles navigation fallback', async () => {
  const worker = await text('service-worker.js');
  for (const asset of ['index.html', 'styles.css', 'src/app.js', 'src/domain.js', 'src/storage.js']) {
    assert.match(worker, new RegExp(asset.replaceAll('.', '\\.')));
  }
  assert.match(worker, /projectlog-shell-v1/);
  assert.match(worker, /request\.mode === 'navigate'/);
  assert.match(worker, /caches\.match\('\.\/index\.html'\)/);
});

test('required home-screen icons exist', async () => {
  await access(new URL('../icons/icon-192.png', import.meta.url));
  await access(new URL('../icons/icon-512.png', import.meta.url));
  await access(new URL('../icons/apple-touch-icon.png', import.meta.url));
});
