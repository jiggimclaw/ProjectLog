import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

async function source(path) {
  return readFile(new URL(`../${path}`, import.meta.url), 'utf8');
}

test('HTML provides a mobile app shell with accessible landmarks', async () => {
  const html = await source('index.html');
  assert.match(html, /<title>ProjectLog<\/title>/);
  assert.match(html, /<meta name="viewport"[^>]+viewport-fit=cover/);
  assert.match(html, /<link rel="manifest" href="\.\/manifest\.webmanifest">/);
  assert.match(html, /<main id="app-main"/);
  assert.match(html, /aria-label="Hauptnavigation"/);
  assert.match(html, /aria-live="polite"/);
  assert.match(html, /<dialog id="editor-dialog"/);
});

test('CSS includes safe areas, dark mode, touch sizes and reduced motion', async () => {
  const css = await source('styles.css');
  assert.match(css, /env\(safe-area-inset-bottom\)/);
  assert.match(css, /@media \(prefers-color-scheme: dark\)/);
  assert.match(css, /min-height:\s*44px/);
  assert.match(css, /@media \(prefers-reduced-motion: reduce\)/);
});

test('app wires repository, URL commands, forms, backup and service worker', async () => {
  const app = await source('src/app.js');
  assert.match(app, /new ProjectLogRepository/);
  assert.match(app, /parseLaunchCommand\(window\.location\.href\)/);
  assert.match(app, /exportBackup\(/);
  assert.match(app, /importBackup\(/);
  assert.match(app, /serviceWorker\.register/);
  assert.match(app, /openEditor/);
  assert.match(app, /removeProjectCascade/);
});
