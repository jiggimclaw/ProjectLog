import test from 'node:test';
import assert from 'node:assert/strict';
import { parseLaunchCommand } from '../src/router.js';

test('parses a new project action', () => {
  assert.deepEqual(
    parseLaunchCommand('https://example.test/?action=new-project'),
    { type: 'new-project' },
  );
});

test('parses a prefilled bug action only with a project ID', () => {
  assert.deepEqual(
    parseLaunchCommand('https://example.test/?action=new-bug&project=PRJ-ABC123&title=%20Crash%20beim%20Start%20'),
    { type: 'new-bug', projectId: 'PRJ-ABC123', title: 'Crash beim Start' },
  );
  assert.deepEqual(
    parseLaunchCommand('https://example.test/?action=new-bug'),
    { type: 'invalid', message: 'Für einen neuen Bug fehlt das Projekt.' },
  );
});

test('parses a prefilled idea action', () => {
  assert.deepEqual(
    parseLaunchCommand('https://example.test/?action=new-idea&project=PRJ-ABC123'),
    { type: 'new-idea', projectId: 'PRJ-ABC123', title: '' },
  );
});

test('parses project navigation and normalizes an unknown view', () => {
  assert.deepEqual(
    parseLaunchCommand('https://example.test/?project=PRJ-ABC123&view=bugs'),
    { type: 'open-project', projectId: 'PRJ-ABC123', view: 'bugs' },
  );
  assert.deepEqual(
    parseLaunchCommand('https://example.test/?project=PRJ-ABC123&view=admin'),
    { type: 'open-project', projectId: 'PRJ-ABC123', view: 'overview' },
  );
});

test('rejects destructive or unknown URL actions', () => {
  assert.deepEqual(
    parseLaunchCommand('https://example.test/?action=delete-project&project=PRJ-ABC123'),
    { type: 'invalid', message: 'Diese URL-Aktion wird nicht unterstützt.' },
  );
  assert.deepEqual(
    parseLaunchCommand('https://example.test/?action=resolve-bug&bug=BUG-0001'),
    { type: 'invalid', message: 'Diese URL-Aktion wird nicht unterstützt.' },
  );
});

test('returns no command for a regular launch and rejects oversized fields', () => {
  assert.deepEqual(parseLaunchCommand('https://example.test/'), { type: 'none' });
  const longTitle = 'x'.repeat(121);
  assert.deepEqual(
    parseLaunchCommand(`https://example.test/?action=new-idea&project=PRJ-1&title=${longTitle}`),
    { type: 'invalid', message: 'Der vorausgefüllte Titel ist zu lang.' },
  );
});
